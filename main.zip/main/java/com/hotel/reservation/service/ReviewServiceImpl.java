package com.hotel.reservation.service;

import com.hotel.reservation.model.Review;
import com.hotel.reservation.repository.FileReviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReviewServiceImpl implements ReviewService {
    private final FileReviewRepository reviewRepository;

    @Autowired
    public ReviewServiceImpl(FileReviewRepository reviewRepository) {
        this.reviewRepository = reviewRepository;
    }

    @Override
    public List<Review> getAllReviews() {
        return reviewRepository.findAll();
    }

    @Override
    public List<Review> getApprovedReviews() {
        return reviewRepository.findAll().stream()
                .filter(Review::isApproved)
                .collect(Collectors.toList());
    }

    @Override
    public List<Review> getReviewsByRoom(String roomNumber) {
        return reviewRepository.findByRoomNumber(roomNumber).stream()
                .filter(Review::isApproved)
                .collect(Collectors.toList());
    }

    @Override
    public Review getReviewById(String id) {
        return reviewRepository.findById(id);
    }

    @Override
    public Review createReview(Review review) {
        return reviewRepository.save(review);
    }

    @Override
    public Review updateReview(String id, Review review) {
        Review existingReview = getReviewById(id);
        if (existingReview == null) {
            return null;
        }
        review.setId(id);
        return reviewRepository.save(review);
    }

    @Override
    public void deleteReview(String id) {
        reviewRepository.deleteById(id);
    }

    @Override
    public Review approveReview(String id) {
        Review review = getReviewById(id);
        if (review != null) {
            review.setApproved(true);
            return reviewRepository.save(review);
        }
        return null;
    }
}