package com.hotel.reservation.repository;

import com.hotel.reservation.model.GuestReview;
import com.hotel.reservation.model.Review;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Repository
public class FileReviewRepository {
    private final String filePath;

    public FileReviewRepository(@Value("${reviews.file.path}") String filePath) {
        this.filePath = filePath;
        initializeFile();
    }

    private void initializeFile() {
        try {
            Path path = Paths.get(filePath);
            if (!Files.exists(path)) {
                Files.createDirectories(path.getParent());
                Files.createFile(path);
            }
        } catch (IOException e) {
            throw new RuntimeException("Could not initialize reviews file", e);
        }
    }

    public List<Review> findAll() {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            return reader.lines()
                    .map(this::parseReview)
                    .collect(Collectors.toList());
        } catch (IOException e) {
            throw new RuntimeException("Failed to read reviews", e);
        }
    }

    public Review findById(String id) {
        return findAll().stream()
                .filter(review -> review.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public List<Review> findByRoomNumber(String roomNumber) {
        return findAll().stream()
                .filter(review -> review.getRoomNumber().equals(roomNumber))
                .collect(Collectors.toList());
    }

    public Review save(Review review) {
        List<Review> reviews = findAll();

        if (review.getId() == null || review.getId().isEmpty()) {
            review.setId(UUID.randomUUID().toString());
            review.setReviewDate(LocalDate.now());
            reviews.add(review);
        } else {
            reviews = reviews.stream()
                    .map(r -> r.getId().equals(review.getId()) ? review : r)
                    .collect(Collectors.toList());
        }

        writeAll(reviews);
        return review;
    }

    public void deleteById(String id) {
        List<Review> reviews = findAll().stream()
                .filter(review -> !review.getId().equals(id))
                .collect(Collectors.toList());
        writeAll(reviews);
    }

    private void writeAll(List<Review> reviews) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (Review review : reviews) {
                writer.write(review.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to write reviews", e);
        }
    }

    private Review parseReview(String line) {
        String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
        Review review = new Review();
        review.setId(parts[0]);
        review.setGuestName(parts[1]);
        review.setRoomNumber(parts[2]);
        review.setRating(Integer.parseInt(parts[3]));
        review.setComment(parts[4].replace("\\,", ","));
        review.setReviewDate(LocalDate.parse(parts[5]));
        review.setApproved(Boolean.parseBoolean(parts[6]));

        if (parts.length > 7) {
            GuestReview guestReview = new GuestReview();
            guestReview.setId(review.getId());
            guestReview.setGuestName(review.getGuestName());
            guestReview.setRoomNumber(review.getRoomNumber());
            guestReview.setRating(review.getRating());
            guestReview.setComment(review.getComment());
            guestReview.setReviewDate(review.getReviewDate());
            guestReview.setApproved(review.isApproved());
            guestReview.setEmail(parts[7]);
            return guestReview;
        }

        return review;
    }
}