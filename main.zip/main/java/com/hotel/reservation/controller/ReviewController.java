package com.hotel.reservation.controller;

import com.hotel.reservation.model.GuestReview;
import com.hotel.reservation.model.Review;
import com.hotel.reservation.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@Controller
@RequestMapping("/reviews")
public class ReviewController {
    private final ReviewService reviewService;

    @Autowired
    public ReviewController(ReviewService reviewService) {
        this.reviewService = reviewService;
    }

    @GetMapping
    public String viewAllReviews(Model model) {
        model.addAttribute("reviews", reviewService.getAllReviews());
        return "view-reviews";
    }

    @GetMapping("/room/{roomNumber}")
    public String viewRoomReviews(@PathVariable String roomNumber, Model model) {
        model.addAttribute("reviews", reviewService.getReviewsByRoom(roomNumber));
        model.addAttribute("roomNumber", roomNumber);
        return "view-reviews";
    }

    @GetMapping("/add")
    public String showAddReviewForm(Model model) {
        model.addAttribute("review", new GuestReview());
        return "add-review";
    }

    @PostMapping("/add")
    public String addReview(@ModelAttribute GuestReview review) {
        review.setReviewDate(LocalDate.now());
        review.setApproved(false); // New reviews need admin approval
        reviewService.createReview(review);
        return "redirect:/reviews";
    }

    @GetMapping("/edit/{id}")
    public String showEditReviewForm(@PathVariable String id, Model model) {
        Review review = reviewService.getReviewById(id);
        model.addAttribute("review", review);
        return "edit-review";
    }

    @PostMapping("/edit/{id}")
    public String updateReview(@PathVariable String id, @ModelAttribute Review review) {
        reviewService.updateReview(id, review);
        return "redirect:/reviews";
    }

    @GetMapping("/delete/{id}")
    public String deleteReview(@PathVariable String id) {
        reviewService.deleteReview(id);
        return "redirect:/reviews";
    }

    @GetMapping("/admin")
    public String adminReviewPanel(Model model) {
        model.addAttribute("reviews", reviewService.getAllReviews());
        return "admin-reviews";
    }

    @GetMapping("/approve/{id}")
    public String approveReview(@PathVariable String id) {
        reviewService.approveReview(id);
        return "redirect:/reviews/admin";
    }
}