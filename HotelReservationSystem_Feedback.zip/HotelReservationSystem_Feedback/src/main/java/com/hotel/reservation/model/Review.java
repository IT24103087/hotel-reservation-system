package com.hotel.reservation.model;

import java.time.LocalDate;

public class Review {
    private String id;
    private String guestName;
    private String roomNumber;
    private int rating;
    private String comment;
    private LocalDate reviewDate;
    private boolean approved;

    // Constructors
    public Review() {
    }

    public Review(String id, String guestName, String roomNumber, int rating, String comment, LocalDate reviewDate, boolean approved) {
        this.id = id;
        this.guestName = guestName;
        this.roomNumber = roomNumber;
        this.rating = rating;
        this.comment = comment;
        this.reviewDate = reviewDate;
        this.approved = approved;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGuestName() {
        return guestName;
    }

    public void setGuestName(String guestName) {
        this.guestName = guestName;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public LocalDate getReviewDate() {
        return reviewDate;
    }

    public void setReviewDate(LocalDate reviewDate) {
        this.reviewDate = reviewDate;
    }

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }

    @Override
    public String toString() {
        return id + "," + guestName + "," + roomNumber + "," + rating + "," +
                comment.replace(",", "\\,") + "," + reviewDate + "," + approved;
    }
}