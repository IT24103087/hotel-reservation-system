package com.hotel.reservation.model;

import java.time.LocalDate;

public class GuestReview extends Review {
    private String email;

    public GuestReview() {
        super();
    }

    public GuestReview(String id, String guestName, String roomNumber, int rating,
                       String comment, LocalDate reviewDate, boolean approved, String email) {
        super(id, guestName, roomNumber, rating, comment, reviewDate, approved);
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return super.toString() + "," + email;
    }
}