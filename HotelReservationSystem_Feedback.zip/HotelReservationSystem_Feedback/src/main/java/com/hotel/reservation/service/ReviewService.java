package com.hotel.reservation.service;

import com.hotel.reservation.model.Review;

import java.util.List;

public interface ReviewService {
    List<Review> getAllReviews();
    List<Review> getApprovedReviews();
    List<Review> getReviewsByRoom(String roomNumber);
    Review getReviewById(String id);
    Review createReview(Review review);
    Review updateReview(String id, Review review);
    void deleteReview(String id);
    Review approveReview(String id);
}